# Authoring brief (compact)

The whole contract for writing one lesson spec, sized to read once. `node scripts/brief.mts
<project>` prints this plus the project's settings, word budget, illustration catalogue, fact
ledger and a gold example — everything an author needs in one call. The long-form guide
(`docs/AUTHORING_GUIDE.md`) only adds background.

## The file
`projects/<p>/specs/<id>.json`: `{"id","title","outputFilename" (…​.mp4, letters/digits/_.-),
"episode"?, "module", "topicGroup", "scenes":[…]}`. Every scene: `type`, `kicker` (1–3 words)
and `narration` (exactly what is spoken).

## The arc (quality bar)
intro (names the topic first; second half enumerates the `learn` bullets in order, reusing a
distinctive word of each) → hook (a question/stake) → teach, one idea per scene: definition,
figures (≥ a third of scenes; motion over slides), steps, compare → a real-world beat →
mistake (the common error, wrong vs right) → check → answer → recap (2–3 bullets
"heading — detail" + one memorable takeaway). Warm, second-person, spoken sentences; say
items in on-screen order; `[pause]` after a key idea. Accuracy beats colour.

## Hard rules (preflight enforces)
- **Facts:** only what the fact ledger states; every digit in narration or on screen must be in
  it. No invented numbers, brands or claims.
- **Sync:** every reveal fires on a spoken word. Give each callout / step / chip / compare item /
  answer point / recap bullet a `say` list: a word (≥4 letters) literally in that scene's
  narration, in on-screen order; a stem matches inflections. Side figures ≤6 callouts.
- **Abbreviations:** never in narration (the voice spells them). Speak the full form; the
  abbreviation may be on screen, where it is emphasised automatically.
- **Numbers & symbols:** English: write units/ratios in words ("millimetres of mercury",
  "120 over 80"). Hindi/Marathi/Kannada: whole numbers as digits; decimals, percentages,
  ranges in words; no `% – / + =` in narration.
- **Language:** one per project; narration and all on-screen text in it (native script for
  hi/mr/kn); spelling per `style.spelling`.
- **Layout:** preflight's dry-run render + text audit reject overflow and colliding text —
  no need to look at images unless something fails.

## Scene shapes (fields in brackets are optional)
- intro `{topic "A: B", subtitle, learn[2–4]}`
- hook `{headline, question, [highlight[words]], [chips[{label,say}]]}`
- definition `{term, plain, [highlight{word:"accent"|"variable"|"constant"}], [chips[≤5 {label,say}]]}`
- steps `{[title], steps[2–6 {label, [detail], say}], [startAt]}`
- figure `{art, [title], [data], [callouts[{anchor,label,[text],say}]], [caption]}` — diagrams
  take `data.items[{label,[note],say}]` (callouts derived); pack arts take `callouts` on their anchors
- compare `{[question], left{keyword,title,color,items[{label,say}]}, right{…}, [tip]}`
  (color: variable|constant|accent)
- mistake `{[title], wrong{label, lines[≤4 short]}, right{label, lines[≤4]}, [note]}`
- check `{question}` → answer `{question (same), answer, points[≤4 {label,say}]}`
- recap `{bullets[2–3 {label "heading — detail", say, [color]}], takeaway, [signoff]}`
- graph data `{direction "LR"|"TB", nodes[2–12 {id,label≤28,[shape box|circle|pill],[tone]}],
  edges[{from,to,[label≤22],[tone]}], steps[1–10 {say, [show[ids|"a>b"]], [flow["a>b"]],
  [focus id], [token[ids]], [cut["a>b"]], [note≤80]}]}`; tones: ink blue red teal green sun orange pink

## Efficient workflow (keeps tokens low without lowering the bar)
1. `node scripts/brief.mts <p>` once. Don't read source code or other specs.
2. Write the whole spec in one `Write`, aiming at ~90% of the word budget (drafts run long;
   a trim pass costs a whole extra round). Preflight prints `⏱ est · words · band` every run.
3. `node scripts/preflight.mts <p> <id> --no-render` (seconds). Fix with small `Edit`s — never
   rewrite the file or use scripts to regenerate it. `--map` prints which word fires each
   reveal when a sync problem is unclear.
4. When the text stages are clean: `node scripts/preflight.mts <p> <id>` once (dry-run render +
   text audit). Fix any layout error it names.
5. Report in ≤6 lines: result line, runtime estimate, anything you could not state.
