/**
 * The pipeline's own test suite — run before trusting any change to src/ or scripts/.
 *
 *   npm test                 all gates (≈3–5 min: renders fixture stills)
 *   npm test -- --fast       skip the fixture render stage
 *
 *   1 types      tsc over src/ and scripts/
 *   2 lint       no SVG text anywhere (render-only layout bug class)
 *   3 units      sync matcher, schedule, catalog, project defaults
 *   4 specs      every project validates with 0 errors
 *   5 fixtures   projects/fixtures (every scene type, every diagram at min/max) rendered
 *                with synthetic timings → review gate: no layout overflow; plus a short
 *                real render through the full encode path
 */
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {existsSync, readdirSync, rmSync} from 'node:fs';
import {join} from 'node:path';
import {ROOT, listProjects, loadProject, readTimings, specIds} from './lib/paths.mts';
import {writeFakeTimings} from './lib/fake-timings.mts';
import {matchPhrases, revealGroups, syncProblems} from '../src/sync.ts';
import {retime, planTransitions} from '../src/schedule.ts';
import {CATALOG, calloutsFor} from '../src/art/catalog.ts';
import {withDefaults, spoken} from '../src/project.ts';
import {speakTokens} from './lib/speak.mts';
import {numbersIn, speechHazards, spellingProblems} from './lib/grounding.mts';
import {revealTimes} from '../src/sync.ts';
import {uncovered} from './lib/coverage.mts';

const fast = process.argv.includes('--fast');
let failed = 0;
const step = (name: string, fn: () => boolean | void) => {
  const t0 = Date.now();
  let ok = false;
  try {
    ok = fn() !== false;
  } catch (e) {
    console.log(`   ${(e as Error).message.split('\n').slice(0, 6).join('\n   ')}`);
  }
  if (!ok) failed++;
  console.log(`${ok ? '✅' : '❌'} ${name}  (${((Date.now() - t0) / 1000).toFixed(1)}s)`);
};
const sh = (cmd: string, args: string[], quiet = true) => {
  const r = spawnSync(cmd, args, {cwd: ROOT, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024});
  if (r.status !== 0 || !quiet) console.log((r.stdout + r.stderr).trim().split('\n').slice(-25).map((l) => '   ' + l).join('\n'));
  return r.status === 0;
};

step('1 types (tsc)', () => sh('npx', ['tsc', '--noEmit']));
step('2 lint: no SVG text', () => sh('node', ['scripts/lint-art.mts']));

step('3 units', () => {
  // matcher: in-order, substring ≥4, floor, misses
  // every on-screen character needs a vendored glyph (render servers have no reliable fallback)
  const cov = {name: 't', series: 's', lang: 'hi', brand: {signoff: 'x', episodeLabel: 'EP.'}};
  assert.deepEqual(uncovered({scenes: [{narration: 'रक्तचाप 120 → O₂ ✓ 🙂'}]}, cov), ['🙂'], 'glyph coverage');
  assert.deepEqual(matchPhrases(['the', 'leak', 'test', 'then', 'brushing'], [['leak'], ['brush']]), [1, 4]);
  assert.deepEqual(matchPhrases(['brush', 'leak'], [['leak'], ['brush']]), [1, -1], 'order is enforced');
  assert.deepEqual(matchPhrases(['remove'], [['removable']]), [-1], '"remove" is not "removable"');
  assert.deepEqual(matchPhrases(['a', 'b', 'leak'], [['leak']], 3), [-1], 'floor respected');
  // intro ticks wait for the enumeration
  const intro: any = {type: 'intro', kicker: 'k', topic: 'Leak testing', subtitle: 's', learn: ['why leaks matter'], narration: 'Leak testing matters. Today we cover a lot of ground about it. By the end you will know why leaks matter.'};
  assert.equal(syncProblems(intro).length, 0);
  assert.equal(syncProblems({...intro, narration: 'Why leaks matter is our topic today. Nothing else here at all to see, honestly, none.'}).length, 1, 'learn word before the 40% floor must not count');
  // say overrides label words
  const steps: any = {type: 'steps', kicker: 'k', narration: 'First remove the caps.', steps: [{label: 'Removable parts', say: ['remove']}]};
  assert.equal(syncProblems(steps).length, 0);
  assert.equal(revealGroups(steps).steps.phrases[0][0], 'remove');
  // schedule
  const t = retime({id: 'x', fps: 30, totalDurationInFrames: 0, voice: {id: 'v', name: 'v'}, scenes: [0, 1, 2].map((i) => ({index: i + 1, type: i === 1 ? 'check' : 'steps', narration: '', audioFile: '', voDurationInSeconds: 1, voDurationInFrames: 30, leadFrames: 0, tailFrames: 0, durationInFrames: 0, startFrame: 0, captions: []})) as any});
  assert.equal(t.scenes[1].startFrame, t.scenes[0].startFrame + t.scenes[0].durationInFrames);
  assert.equal(t.totalDurationInFrames, t.scenes.reduce((n, s) => n + s.durationInFrames, 0));
  assert.deepEqual(planTransitions(['intro', 'check', 'answer', 'figure', 'figure', 'recap']).map((p) => p.kind), ['cut', 'flood', 'slide', 'portal', 'slide', 'zoomout']);
  // catalog: every diagram rejects bad data and derives callouts from items
  for (const [name, e] of Object.entries(CATALOG)) {
    assert.ok(e.doc && e.layout, `${name} documented`);
    if (e.callouts) assert.ok(e.check({}).length > 0, `${name} rejects empty data`);
    if (['cycle', 'flow', 'timeline', 'hub', 'stack', 'bars'].includes(name)) assert.equal(calloutsFor(name, {items: [{label: 'A'}, {label: 'B'}]})[1].anchor, 'i2');
  }
  // speakable narration: the voice hears words, captions keep the script
  const sp = (x: string) => speakTokens(x, {Purkinje: 'Pur-kin-jee'}).map((t) => t.s).join(' ');
  assert.equal(sp('Rate 60–100 beats, e.g., at rest.'), 'Rate 60 to 100 beats, for example, at rest.');
  assert.equal(sp('About 70% of Purkinje fibres.'), 'About 70 percent of Pur-kin-jee fibres.');
  assert.equal(sp("Let's compare A vs. B."), "Let's compare A versus B!");
  assert.equal(spoken('One. [pause] Two.'), 'One. Two.');
  // numbers: digits and spoken forms, split at punctuation
  assert.deepEqual(numbersIn('forty-four seventy-one; one hundred and twenty. four point nine, 5,000 mL'), [5000, 44, 71, 120, 4.9]);
  assert.ok(speechHazards('It reads 120/80 at 72bpm.', {}).length >= 2);
  assert.equal(spellingProblems([{where: 'x', text: 'fibres and fibers'}]).length, 1, 'mixed spelling is flagged');
  assert.equal(spellingProblems([{where: 'x', text: 'the fibers'}], 'en-GB').length, 1, 'US spelling in an en-GB project is flagged');
  assert.equal(calloutsFor('graph', {nodes: [{id: 'a', label: 'Alpha'}], steps: [{focus: 'a'}]})[0].label, 'Alpha');
  assert.equal(calloutsFor('trace', {segments: [{shape: 'flat'}, {shape: 'spike', label: 'R'}]})[0].anchor, 'i1');
  // timed sync on a real-looking word list
  const r = revealTimes(steps, [{w: 'first', start: 0}, {w: 'remove', start: 0.5}, {w: 'the', start: 0.8}, {w: 'caps', start: 1}], 1.2);
  assert.equal(r.steps[0].t, 0.5);
  // project defaults
  const p = withDefaults('demo', {name: 'Demo'});
  assert.equal(p.voice.name, 'en-IN-NeerjaExpressiveNeural');
  assert.ok(p.pacing.sentencePause > 0 && p.pacing.breathe > 1, 'house pacing is unhurried');
  assert.equal(p.output.dir, 'demo');
  assert.equal(p.rules.sync, 'error');
});

step('4 specs: every project validates', () => listProjects().every((p) => sh('node', ['scripts/validate.mts', p])));
step('4b preflight (text stages) passes on fixtures', () => sh('node', ['scripts/preflight.mts', 'fixtures', '--no-render']));

if (!fast) {
  step('5a fixtures: stills + layout gate', () => {
    for (const id of specIds('fixtures')) writeFakeTimings('fixtures', id);
    return sh('node', ['scripts/review.mts', 'fixtures', '--out', 'iterations/test/fixtures'], false);
  });
  step('5b fixtures: full encode path (short clip)', () => {
    const out = join('iterations', 'test', 'clip');
    rmSync(join(ROOT, out), {recursive: true, force: true});
    return sh('node', ['scripts/render.mts', 'fixtures', 'F02', '--out', out, '--frames', '0-89']) && existsSync(join(ROOT, out));
  });
  // a settled, static layout must still move (camera push + float): QA fails a ≥3 s frozen
  // picture, and a frozen stretch can only be seen in motion — so it is designed out, and this
  // renders 4 s of a definition scene after its last reveal to prove it (no still ≥1.5 s)
  step('5d motion: a settled scene never freezes', () => {
    const t = retime(readTimings('fixtures', 'F02'), loadProject('fixtures').pacing.breathe);
    const st = t.scenes.find((x) => x.type === 'definition')!;
    const from = st.startFrame + st.leadFrames + Math.round(st.voDurationInFrames * 0.9);
    const out = join('iterations', 'test', 'motion');
    rmSync(join(ROOT, out), {recursive: true, force: true});
    if (!sh('node', ['scripts/render.mts', 'fixtures', 'F02', '--out', out, '--frames', `${from}-${from + 120}`])) return false;
    const clip = readdirSync(join(ROOT, out)).find((f) => f.endsWith('.mp4'));
    const r = spawnSync('ffmpeg', ['-hide_banner', '-nostats', '-i', join(ROOT, out, clip!), '-vf', 'freezedetect=n=-60dB:d=1.5', '-an', '-f', 'null', '-'], {encoding: 'utf8'});
    return !/freeze_start/.test(r.stderr);
  });
  // the text audit must keep catching what used to need a human eye (a long word overflowing
  // a diagram box and colliding with its neighbour) — projects/audit-probe is built to fail
  step('5c text audit catches overflow + collision', () => {
    const r = spawnSync('node', ['scripts/preflight.mts', 'audit-probe'], {cwd: ROOT, encoding: 'utf8'});
    return r.status === 1 && /text overflows its box/.test(r.stdout) && /text collides/.test(r.stdout);
  });
}

console.log(failed ? `\n❌ ${failed} stage(s) failed` : '\n✅ pipeline healthy');
process.exit(failed ? 1 : 0);
