/**
 * What every art is and accepts — pure data, shared by the renderer (src/art/index.ts) and
 * the validator, so a figure's data and anchor names are checked before anything renders.
 *
 * Two families:
 *   diagrams — generic, data-driven (`data.items`); work for any subject. Anchors are
 *              i1…iN, and callouts are derived from the items unless the spec gives them.
 *   packs    — hand-drawn domain illustrations with fixed anchors (src/art/packs/*).
 */

export type Item = {label: string; note?: string; say?: string[]; when?: string};
export const TONE_NAMES = ['ink', 'blue', 'red', 'teal', 'green', 'sun', 'orange', 'pink'];
export type Callout = {anchor: string; label: string; text?: string; say?: string[]};

type Entry = {
  layout: 'side' | 'full';
  /** one line for the authoring guide */
  doc: string;
  anchors: (data: any) => string[];
  /** human-readable problems with `data` (empty = fine) */
  check: (data: any) => string[];
  /** callouts when the spec omits them */
  callouts?: (data: any) => Callout[];
};

const itemsCheck =
  (min: number, max: number, maxLabel: number, extra?: (data: any) => string[]) =>
  (data: any): string[] => {
    const items = data?.items;
    if (!Array.isArray(items)) return [`data.items must be an array of {label, note?, say?}`];
    const out: string[] = [];
    if (items.length < min || items.length > max) out.push(`needs ${min}–${max} items (has ${items.length})`);
    items.forEach((it: any, i: number) => {
      if (typeof it?.label !== 'string' || !it.label.trim()) out.push(`items[${i}].label missing`);
      else if (it.label.length > maxLabel) out.push(`items[${i}].label "${it.label}" is ${it.label.length} chars (max ${maxLabel})`);
      if (it.note !== undefined && (typeof it.note !== 'string' || it.note.length > 70)) out.push(`items[${i}].note must be a string ≤ 70 chars`);
    });
    return [...out, ...(extra?.(data) ?? [])];
  };
const itemAnchors = (data: any) => (Array.isArray(data?.items) ? data.items.map((_: unknown, i: number) => `i${i + 1}`) : []);
const itemCallouts = (data: any): Callout[] => (data?.items ?? []).map((it: Item, i: number) => ({anchor: `i${i + 1}`, label: it.label, text: it.note, say: it.say}));
const fixed = (names: string[]) => ({anchors: () => names, check: () => []});

export const CATALOG: Record<string, Entry> = {
  /* ---------------------------------------------------------------- generic diagrams */
  cycle: {
    layout: 'full',
    doc: 'Stages on a closed loop (a process that repeats). data: {items: 3–8 {label ≤26, note?}, start?: "PATIENT"}',
    anchors: itemAnchors,
    check: itemsCheck(3, 8, 26, (d) => (d.start !== undefined && (typeof d.start !== 'string' || d.start.length > 12) ? ['start must be a short tag (≤12 chars)'] : [])),
    callouts: itemCallouts,
  },
  flow: {
    layout: 'full',
    doc: 'A linear pipeline, left to right. data: {items: 2–6 {label ≤28, note?}}',
    anchors: itemAnchors,
    check: itemsCheck(2, 6, 28),
    callouts: itemCallouts,
  },
  timeline: {
    layout: 'full',
    doc: 'Events in time order. data: {items: 3–7 {when ≤12 (e.g. "1928", "Day 3"), label ≤30, note?}}',
    anchors: itemAnchors,
    check: itemsCheck(3, 7, 30, (d) => (d.items ?? []).flatMap((it: any, i: number) => (typeof it?.when === 'string' && it.when.length <= 12 ? [] : [`items[${i}].when must be a string ≤ 12 chars`]))),
    callouts: itemCallouts,
  },
  hub: {
    layout: 'full',
    doc: 'One central idea with 3–6 related parts. data: {center ≤22, items: 3–6 {label ≤22, note?}}',
    anchors: itemAnchors,
    check: itemsCheck(3, 6, 22, (d) => (typeof d?.center === 'string' && d.center.length <= 22 ? [] : ['center must be a string ≤ 22 chars'])),
    callouts: itemCallouts,
  },
  stack: {
    layout: 'full',
    doc: 'Layers, top to bottom (levels, strata, a protocol stack). data: {items: 2–6 {label ≤30, note?}}',
    anchors: itemAnchors,
    check: itemsCheck(2, 6, 30),
    callouts: itemCallouts,
  },
  image: {
    layout: 'side',
    doc: 'A photo/diagram file under public/ with labelled points. data: {src, credit, points: {name: [x 0–1, y 0–1]}}; callouts required (anchor = point name)',
    anchors: (d) => Object.keys(d?.points ?? {}),
    check: (d) => {
      const out: string[] = [];
      if (typeof d?.src !== 'string') out.push('data.src (path under public/) required');
      if (typeof d?.credit !== 'string' || !d.credit.trim()) out.push('data.credit required (source + licence — only use images you may publish)');
      for (const [k, v] of Object.entries(d?.points ?? {})) if (!Array.isArray(v) || v.length !== 2 || v.some((n: any) => typeof n !== 'number' || n < 0 || n > 1)) out.push(`points.${k} must be [x, y] fractions 0–1`);
      if (!Object.keys(d?.points ?? {}).length) out.push('data.points needs at least one point');
      return out;
    },
  },

  bars: {
    layout: 'full',
    doc: 'Quantities compared, growing as spoken with count-up values. data: {unit?, max?, ref?: {value, label}, items: 2–8 {label ≤24, value: number, display?, tone?, note?, say?}}',
    anchors: itemAnchors,
    check: itemsCheck(2, 8, 24, (d) => [
      ...(d.items ?? []).flatMap((it: any, i: number) => (typeof it?.value === 'number' && it.value >= 0 ? [] : [`items[${i}].value must be a number ≥ 0`])),
      ...(d.items ?? []).flatMap((it: any, i: number) => (it?.tone === undefined || TONE_NAMES.includes(it.tone) ? [] : [`items[${i}].tone must be one of ${TONE_NAMES.join(', ')}`])),
      ...(d.unit !== undefined && (typeof d.unit !== 'string' || d.unit.length > 8) ? ['unit must be ≤ 8 chars'] : []),
    ]),
    callouts: itemCallouts,
  },
  trace: {
    layout: 'full',
    doc: 'A waveform drawn by a moving pen (ECG, action potential, pressure/sound wave). data: {grid?, repeat? 1–4, segments: 2–24 {shape: flat|bump|spike|dip|plateau|rise|fall, w?, h? (−1…1.2), label? ≤10, note?, say?}}; labelled segments light up as spoken',
    anchors: (d) => (d?.segments ?? []).filter((s: any) => s?.label).map((_: unknown, i: number) => `i${i + 1}`),
    check: (d) => {
      const segs: any[] = Array.isArray(d?.segments) ? d.segments : [];
      const out: string[] = [];
      if (segs.length < 2 || segs.length > 24) out.push(`needs 2–24 segments (has ${segs.length})`);
      if (!segs.some((s) => s?.label)) out.push('label at least one segment (labels are what the narration reveals)');
      segs.forEach((s, i) => {
        if (s?.shape !== undefined && !['flat', 'bump', 'spike', 'dip', 'plateau', 'rise', 'fall'].includes(s.shape)) out.push(`segments[${i}].shape unknown`);
        if (s?.label !== undefined && (typeof s.label !== 'string' || s.label.length > 10)) out.push(`segments[${i}].label ≤ 10 chars`);
        if (s?.h !== undefined && (typeof s.h !== 'number' || s.h < -1 || s.h > 1.2)) out.push(`segments[${i}].h must be −1…1.2`);
      });
      return out;
    },
    callouts: (d) => (d?.segments ?? []).filter((s: any) => s?.label).map((s: any, i: number) => ({anchor: `i${i + 1}`, label: s.label, text: s.note, say: s.say})),
  },
  graph: {
    layout: 'full',
    doc: 'Any system/process/relationship as nodes + edges, built up and animated step by step (flows, travelling token, focus). data: {direction?: LR|TB, nodes: 2–12 {id, label ≤28, shape?: box|circle|pill, tone?, group?}, edges?: ≤18 {from, to, label?, tone?, dashed?}, groups?: [{id, label}], steps: 1–10 {say?, show?, flow?, focus?, token?, loop?, cut?, note?}}',
    anchors: (d) => [...(d?.nodes ?? []).map((n: any) => n.id), ...(d?.steps ?? []).map((_: unknown, i: number) => `s${i + 1}`)],
    check: (d) => {
      const out: string[] = [];
      const nodes: any[] = Array.isArray(d?.nodes) ? d.nodes : [];
      const edges: any[] = Array.isArray(d?.edges) ? d.edges : [];
      const steps: any[] = Array.isArray(d?.steps) ? d.steps : [];
      if (nodes.length < 2 || nodes.length > 12) out.push(`needs 2–12 nodes (has ${nodes.length})`);
      if (edges.length > 18) out.push(`max 18 edges (has ${edges.length})`);
      if (steps.length < 1 || steps.length > 10) out.push(`needs 1–10 steps (has ${steps.length})`);
      if (d?.direction !== undefined && !['LR', 'TB'].includes(d.direction)) out.push('direction must be LR or TB');
      const ids = new Set<string>();
      nodes.forEach((n, i) => {
        if (typeof n?.id !== 'string' || !/^[\w-]+$/.test(n.id)) out.push(`nodes[${i}].id must be a word`);
        else if (ids.has(n.id)) out.push(`duplicate node id "${n.id}"`);
        else ids.add(n.id);
        if (typeof n?.label !== 'string' || !n.label) out.push(`nodes[${i}].label missing`);
        else if (n.label.length > 28) out.push(`nodes[${i}].label is ${n.label.length} chars (max 28)`);
        if (n.shape !== undefined && !['box', 'circle', 'pill'].includes(n.shape)) out.push(`nodes[${i}].shape must be box|circle|pill`);
        if (n.tone !== undefined && !TONE_NAMES.includes(n.tone)) out.push(`nodes[${i}].tone must be one of ${TONE_NAMES.join(', ')}`);
        if (n.group !== undefined && !(d.groups ?? []).some((g: any) => g.id === n.group)) out.push(`nodes[${i}].group "${n.group}" not in groups`);
      });
      const eids = new Set<string>();
      edges.forEach((e, i) => {
        if (!ids.has(e?.from) || !ids.has(e?.to)) out.push(`edges[${i}] ${e?.from}>${e?.to}: unknown node`);
        eids.add(`${e?.from}>${e?.to}`);
        if (e.label && e.label.length > 22) out.push(`edges[${i}].label max 22 chars`);
        if (e.tone !== undefined && !TONE_NAMES.includes(e.tone)) out.push(`edges[${i}].tone must be one of ${TONE_NAMES.join(', ')}`);
      });
      steps.forEach((s, i) => {
        for (const x of s?.show ?? []) if (!ids.has(x) && !eids.has(x)) out.push(`steps[${i}].show "${x}" is neither a node id nor an edge "from>to"`);
        for (const x of s?.flow ?? []) if (!eids.has(x)) out.push(`steps[${i}].flow "${x}" is not an edge "from>to"`);
        for (const x of s?.cut ?? []) if (!eids.has(x)) out.push(`steps[${i}].cut "${x}" is not an edge "from>to"`);
        if (s?.focus !== undefined && !ids.has(s.focus)) out.push(`steps[${i}].focus "${s.focus}" unknown`);
        const tok: string[] = s?.token ?? [];
        tok.forEach((x, j) => {
          if (!ids.has(x)) out.push(`steps[${i}].token "${x}" unknown`);
          if (j && !eids.has(`${tok[j - 1]}>${x}`) && !eids.has(`${x}>${tok[j - 1]}`)) out.push(`steps[${i}].token hop ${tok[j - 1]}→${x} has no edge`);
        });
        if (s?.note !== undefined && (typeof s.note !== 'string' || s.note.length > 80)) out.push(`steps[${i}].note must be ≤ 80 chars`);
        if (!s?.say && !s?.focus && !(s?.show ?? []).some((x: string) => ids.has(x)) && !s?.label) out.push(`steps[${i}] needs say, focus, label or a shown node (to know when it is spoken)`);
      });
      return out;
    },
    callouts: (d) =>
      (d?.steps ?? []).map((s: any, i: number) => {
        const node = (id?: string) => (d.nodes ?? []).find((n: any) => n.id === id);
        const first = (s.show ?? []).map(node).find(Boolean);
        return {anchor: `s${i + 1}`, label: s.label ?? node(s.focus)?.label ?? first?.label ?? `Step ${i + 1}`, text: s.note, say: s.say};
      }),
  },

  /* ---------------------------------------------------------------- pack: endoscopy */
  scope: {layout: 'side', doc: 'Flexible endoscope, whole instrument', ...fixed(['controlHead', 'valves', 'biopsyPort', 'insertionTube', 'distalTip', 'connector', 'channels'])},
  channels: {layout: 'side', doc: 'Insertion-tube cross-section', ...fixed(['suction', 'air', 'water', 'light', 'ccd', 'wires', 'sheath'])},
  biofilm: {layout: 'side', doc: 'Channel wall: soil → bacteria → biofilm; disinfectant/flow/brush events', ...fixed(['wall', 'soil', 'bacteria', 'matrix', 'disinfectant', 'flow', 'brush'])},
  leaktest: {layout: 'side', doc: 'Leak tester, gauge, breach and bubbles', ...fixed(['tester', 'gauge', 'sheath', 'breach', 'bubbles', 'connector'])},
  elevator: {layout: 'side', doc: 'Duodenoscope distal tip with elevator and recess', ...fixed(['tip', 'lens', 'elevator', 'accessory', 'recess'])},
  drying: {layout: 'side', doc: 'Alcohol/air drying, coiled vs cabinet storage', ...fixed(['alcohol', 'air', 'moisture', 'coiled', 'cabinet'])},
  aer: {layout: 'side', doc: 'Automated endoscope reprocessor, connectors, cycle record', ...fixed(['reprocessor', 'connectors', 'missing', 'record'])},
};

// pack: heart (src/art/packs/heart.tsx) — anchors mirror HEART_ANCHORS there
CATALOG.heart = {
  layout: 'side',
  doc: 'Human heart, frontal section, beating. Anatomy: ra rv la lv septum apex svc ivc aorta trunk pv · valves: tricuspid pulmonary mitral aortic chordae · events: flowRight flowLeft (blood routes) · conduction: sa av his branches purkinje (wave grows as named). data: {bpm?, beat?}',
  anchors: () => ['ra', 'rv', 'la', 'lv', 'septum', 'apex', 'svc', 'ivc', 'aorta', 'trunk', 'pv', 'tricuspid', 'pulmonary', 'mitral', 'aortic', 'chordae', 'sa', 'av', 'his', 'branches', 'purkinje', 'flowRight', 'flowLeft'],
  check: (d) => (d?.bpm !== undefined && (typeof d.bpm !== 'number' || d.bpm < 40 || d.bpm > 120) ? ['bpm must be 40–120'] : []),
};

// pack: circulation (src/art/packs/circulation.tsx)
CATALOG.artery = {layout: 'side', doc: 'Cut-open artery: blood flows, each beat sends a pressure wave stretching the wall; a gauge follows it. anchors: heart wall blood gauge · events: systole diastole (gauge marks peak / floor). data {bpm?}', ...fixed(['heart', 'wall', 'blood', 'gauge', 'systole', 'diastole'])};
CATALOG.bpmonitor = {layout: 'side', doc: 'Upper arm in a cuff + digital monitor counting up to the reading. anchors: cuff artery monitor sys dia unit. data {sys?: 120, dia?: 80, sysLabel?, diaLabel?, unit?}', ...fixed(['cuff', 'artery', 'monitor', 'sys', 'dia', 'unit'])};
CATALOG.bpscale = {layout: 'side', doc: 'Colour scale of blood-pressure bands; a pin moves to each band as it is named. anchors: low ideal raised high. data {marks?: ["90/60","120/80","140/90"]}', ...fixed(['low', 'ideal', 'raised', 'high'])};

// pack: metabolic (src/art/packs/metabolic.tsx)
CATALOG.insulin = {layout: 'side', doc: 'Pancreas, blood vessel with glucose, body cell. anchors: pancreas glucose insulin receptor uptake cell · events: glucose (sugar rises) insulin (keys leave pancreas) receptor (keys dock) uptake (gates open, glucose enters as energy) type1 (no insulin, sugar piles up) type2 (keys dock, locks don\'t respond)', ...fixed(['pancreas', 'glucose', 'insulin', 'receptor', 'uptake', 'cell', 'type1', 'type2'])};
// pack: respiratory (src/art/packs/respiratory.tsx)
CATALOG.lungs = {layout: 'side', doc: 'Airway, lungs and diaphragm, breathing. anchors: trachea bronchi lungs diaphragm alveoli · events: inhale (diaphragm flattens, lungs expand, air in) exhale (diaphragm domes, air out; then keeps breathing)', ...fixed(['trachea', 'bronchi', 'lungs', 'diaphragm', 'alveoli', 'inhale', 'exhale'])};
CATALOG.alveolus = {layout: 'side', doc: 'One air sac wrapped by a capillary; red cells arrive blue, leave red. anchors: alveolus capillary wall rbc · events: oxygen (O₂ into blood) co2 (CO₂ out to the sac)', ...fixed(['alveolus', 'capillary', 'wall', 'rbc', 'oxygen', 'co2'])};
// pack: infection (src/art/packs/infection.tsx)
CATALOG.moments = {layout: 'side', doc: 'Patient bed in the dashed patient zone; WHO five moments light up in place. anchors: zone patient m1 (before touching patient) m2 (before clean/aseptic procedure) m3 (after body-fluid exposure risk) m4 (after touching patient) m5 (after touching surroundings)', ...fixed(['zone', 'patient', 'm1', 'm2', 'm3', 'm4', 'm5'])};
CATALOG.hand = {layout: 'side', doc: 'Hand (palm view) with germs; each rubbing step clears its area. anchors: germs palms between thumbs tips missed clean (missed pulses the areas most often missed; clean = all gone)', ...fixed(['germs', 'palms', 'between', 'thumbs', 'tips', 'missed', 'clean'])};

/** Callouts for a figure: the spec's own, else derived from diagram items. */
export const calloutsFor = (art: string, data: any, own?: Callout[]): Callout[] => own ?? CATALOG[art]?.callouts?.(data) ?? [];
