/**
 * Art registry: name → factory. Generic diagrams first; domain packs add hand-drawn arts.
 * To add a pack: write src/art/packs/<name>.tsx (see endoscopy.tsx), spread it in here, and
 * describe its anchors in src/art/catalog.ts so specs are validated against it.
 */
import type {ArtFactory} from './kit';
import {DIAGRAMS} from './diagrams';
import {ENDOSCOPY} from './packs/endoscopy';
import {GRAPH} from './graph';
import {HEART} from './packs/heart';
import {CIRCULATION} from './packs/circulation';
import {METABOLIC} from './packs/metabolic';
import {RESPIRATORY} from './packs/respiratory';
import {INFECTION} from './packs/infection';

export const ARTS: Record<string, ArtFactory> = {...DIAGRAMS, ...GRAPH, ...ENDOSCOPY, ...HEART, ...CIRCULATION, ...METABOLIC, ...RESPIRATORY, ...INFECTION};
export {ArtView, type ArtDef} from './kit';
export {CATALOG, calloutsFor} from './catalog';
