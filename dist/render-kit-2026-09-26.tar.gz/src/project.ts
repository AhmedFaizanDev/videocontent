/**
 * Project = one body of source material turned into a series of lessons, e.g. a client
 * module or a curriculum section. Everything that differs between projects lives in
 * projects/<slug>/project.json; the visual language, motion, sound and scene grammar are
 * global. Pure (no remotion imports): read by Node scripts and passed to Remotion as props.
 */

/** Narration as spoken: [pause] markers are silence, not words. */
export const spoken = (narration: string) => narration.replace(/\[pause\]/gi, ' ').replace(/\s+/g, ' ').trim();

import type {Lang} from './lang.ts';

/** Brand artwork under public/: the full lockup (icon + wordmark) and the icon alone, each with a white variant `<name>-white.png` for dark/gradient grounds. */
export type BrandArt = {lockup: string; icon: string; /** width ÷ height of the lockup artwork */ lockupAspect: number; iconAspect: number};

export type ProjectConfig = {
  slug: string;
  name: string;
  /** Series line on the poster and intro, e.g. "CSSD & Sterilization Practices". */
  series: string;
  /** Narration + on-screen language (src/lang.ts): 'en' | 'hi' | 'mr' | 'kn'. */
  lang: Lang;
  brand: {
    /** Brand artwork (default: MedSkills). */
    art: BrandArt;
    /** Brand name (publish kit, credits). */
    name: string;
    /** Outro line; a recap scene's own `signoff` overrides it. */
    signoff: string;
    /** Prefix for the episode mark ("EP.", "Lesson ", …). */
    episodeLabel: string;
  };
  /** Edge neural voice. `wpm` = its speaking pace at this rate, pauses excluded (voiceover measures it). */
  voice: {name: string; rate: string; pitch: string; wpm: number};
  /**
   * Breathing room. `sentencePause`: extra silence after every sentence (s; 0 = one-pass
   * legacy voicing). `beat`: silence at each [pause] marker in narration. `breathe`:
   * multiplier on the holds before/after each scene's narration (src/schedule.ts).
   */
  pacing: {sentencePause: number; beat: number; breathe: number};
  /** Pronunciation fixes sent to the voice only, one token → one token: {"Purkinje": "Pur-kin-jee"}. */
  lexicon: Record<string, string>;
  /**
   * Key terms of the subject, emphasised wherever they appear on screen (weight + brand
   * colour). Abbreviations (BP, WHO, HbA1c…) are emphasised automatically as chips; the
   * narration must speak their full form (preflight rejects letter-by-letter acronyms).
   */
  terms: string[];
  /** Music bed under public/ (ducked under narration); null for none. */
  music: string | null;
  /** Target runtime per video; validate estimates it, voiceover measures it. */
  length: {minutes: [number, number]};
  rules: {
    first?: string;
    last?: string;
    /** Each group: at least one scene of these types (e.g. [["pseudocode","code"],["example"]]). */
    requireOneOf: string[][];
    /** a reveal whose word is never spoken: 'error' (default) or 'warn' (legacy projects) */
    sync: 'error' | 'warn';
    /** at least this many `figure` scenes per lesson (diagrams/illustrations carry the teaching) */
    minFigures: number;
    /** numbers stated but absent from source/: 'error' (default) · 'warn' · 'off' */
    grounding: 'error' | 'warn' | 'off';
  };
  /** Writing conventions: one spelling system per project. */
  style: {spelling?: 'en-GB' | 'en-US'};
  /** Output folder under output/ (default: the slug). */
  output: {dir: string};
};

export const PROJECT_DEFAULTS: Omit<ProjectConfig, 'slug' | 'name' | 'series'> = {
  lang: 'en',
  brand: {
    art: {lockup: 'brand/medskills-lockup.png', icon: 'brand/medskills-icon.png', lockupAspect: 3.677, iconAspect: 0.972},
    name: 'MedSkills',
    signoff: 'Keep learning with MedSkills.',
    episodeLabel: 'EP.',
  },
  // house voice: Indian English female, unhurried (owner's default, 2026-09-25)
  voice: {name: 'en-IN-NeerjaExpressiveNeural', rate: '+0%', pitch: '+0Hz', wpm: 135},
  pacing: {sentencePause: 0.4, beat: 0.9, breathe: 1.3},
  lexicon: {},
  terms: [],
  music: 'audio/music/bed.mp3',
  length: {minutes: [4, 6]},
  rules: {first: 'intro', last: 'recap', requireOneOf: [], sync: 'error', minFigures: 0, grounding: 'error'},
  style: {},
  output: {dir: ''},
};

/** House voice per language: Indian female neural voices (Edge), with their pace measured on real lessons (2026-09-26). */
export const HOUSE_VOICES: Record<Lang, {name: string; wpm: number}> = {
  en: {name: 'en-IN-NeerjaExpressiveNeural', wpm: 140},
  hi: {name: 'hi-IN-SwaraNeural', wpm: 121},
  mr: {name: 'mr-IN-AarohiNeural', wpm: 96},
  kn: {name: 'kn-IN-SapnaNeural', wpm: 83},
};

export const withDefaults = (slug: string, raw: Partial<ProjectConfig>): ProjectConfig => ({
  ...PROJECT_DEFAULTS,
  ...raw,
  slug,
  lang: raw.lang ?? 'en',
  name: raw.name ?? slug,
  series: raw.series ?? raw.name ?? slug,
  brand: {...PROJECT_DEFAULTS.brand, ...raw.brand, art: {...PROJECT_DEFAULTS.brand.art, ...raw.brand?.art}},
  voice: {...PROJECT_DEFAULTS.voice, ...HOUSE_VOICES[raw.lang ?? 'en'], ...raw.voice},
  pacing: {...PROJECT_DEFAULTS.pacing, ...raw.pacing},
  lexicon: {...PROJECT_DEFAULTS.lexicon, ...raw.lexicon},
  terms: raw.terms ?? [],
  length: {...PROJECT_DEFAULTS.length, ...raw.length},
  rules: {...PROJECT_DEFAULTS.rules, ...raw.rules},
  style: {...PROJECT_DEFAULTS.style, ...raw.style},
  output: {dir: raw.output?.dir || slug},
});
