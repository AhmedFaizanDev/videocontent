import {STACKS} from './fonts';

/**
 * Typography, "Clinical" system (v5). One family per role, across every script we voice:
 *   display  Sora (geometric, confident) → Anek Devanagari / Anek Kannada for Indic text
 *   body     Inter (clinical legibility) → Noto Sans Devanagari / Noto Sans Kannada
 *   mono     IBM Plex Mono (code only)
 * then Noto Sans / Symbols 2 / Math for anything else. Stacks fall through per glyph, so a
 * Hindi label with Latin digits sets each character in the right face. All faces are vendored
 * (src/fonts.ts) — never loaded from the network. Never italic: emphasis is weight + colour.
 */
export const fonts = {
  heading: STACKS.display,
  /** kept for older call sites: the same face (emphasis is weight + colour, never italic) */
  headingItalic: STACKS.display,
  body: STACKS.body,
  label: STACKS.display,
  mono: STACKS.mono,
};

/**
 * Layout tokens (1920×1080). Content lives inside the safe box; the band below
 * `safe.bottom` is reserved for captions; chrome sits in the outer margin.
 */
export const safe = {left: 120, right: 1800, top: 150, bottom: 872, width: 1680};

export const tracking = {display: '-0.02em', title: '-0.01em', label: '0.12em'};

export type NamedColor = 'variable' | 'constant' | 'accent';

/**
 * Colour. A clean off-white foundation (a whisper of the brand's violet, never grey-cold),
 * white surfaces, deep aubergine ink, the MedSkills gradient as the signature, and a
 * clinical spectrum that carries meaning (arterial red, venous blue, oxygen teal,
 * glucose amber, healthy green). Keys keep their historical names so every template and
 * art recolours from here. *Text = passes 4.5:1 on white.
 */
export const brand = {
  magenta: '#D8148C',
  purple: '#7A24A1',
  magentaText: '#B00D72',
  purpleText: '#6A1F8E',
  gradient: 'linear-gradient(135deg, #E0168A 0%, #A51C98 52%, #6E25A3 100%)',
  gradientV: 'linear-gradient(180deg, #D8148C 0%, #7A24A1 100%)',
  tint: '#FBEAF4',
  tintPurple: '#F1E9F8',
};

export const ink = {
  paper: '#F7F6FA', // the page
  paperLight: '#FFFFFF', // cards, plates
  paperShade: '#ECE9F2', // wells, tracks
  desk: '#F1EFF6',
  ink: '#1C1530', // text + outlines
  soft: '#4A4460',
  faint: '#77718C',
  orange: brand.magenta, // the signature accent
  orangeText: brand.magentaText,
  blue: '#2563EB', // venous / deoxygenated
  teal: '#0E9F95', // oxygen, air
  sun: '#F59E0B', // glucose, energy
  sunText: '#92400E',
  red: '#E11D48', // arterial / oxygenated, danger
  green: '#16A34A', // healthy, correct
  pink: brand.purple,
};

/** Hairline + soft elevation for surfaces on the page. */
export const surface = {
  border: '1px solid rgba(28,21,48,0.08)',
  radius: 22,
  shadow: '0 1px 2px rgba(28,21,48,0.06), 0 10px 30px -12px rgba(60,30,90,0.18)',
  shadowHi: '0 2px 6px rgba(28,21,48,0.08), 0 24px 50px -18px rgba(60,30,90,0.30)',
};

/** Spot fill + legible text colour for the three authored roles. */
export const spot = (c?: NamedColor) =>
  c === 'variable'
    ? {fill: ink.sun, text: '#B45309'}
    : c === 'constant'
      ? {fill: ink.teal, text: '#0B6F68'}
      : {fill: ink.blue, text: ink.blue};

export const inkSyntax = {
  keyword: ink.blue,
  value: '#0B6F68',
  string: ink.green,
  comment: ink.faint,
  constant: ink.orangeText,
  op: ink.soft,
  text: ink.ink,
};
