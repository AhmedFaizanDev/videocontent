/**
 * Pure scheduling shared by Remotion (Root/VideoComposition) and the Node scripts
 * (render → SRT). Built timings store the *measured* VO duration + word timeline per
 * scene; this module derives the frame layout (lead/tail breathing room around each
 * line of narration) and the transition plan, so both can change without re-voicing.
 * No remotion imports: Node runs this file directly via type stripping.
 */
import type {VideoTimings, Scene} from './spec';

export const SCHEDULE = {
  /** frames 0..poster-1 are the designed thumbnail card */
  poster: 3,
  firstLead: 40,
  lead: 26,
  tail: 44,
  hookTail: 36,
  /** knowledge check: the thinking pause after the question is read */
  checkTail: 170,
  lastTail: 170,
};

/** Transition windows straddling each scene boundary (frames). */
export const TX = {exit: 16, enter: 24};

/** Frame layout from measured VO; `breathe` scales the holds around each scene (project pacing). */
export function retime(t: VideoTimings, breathe = 1): VideoTimings {
  const b = (n: number) => Math.round(n * breathe);
  let cursor = 0;
  const n = t.scenes.length;
  const scenes = t.scenes.map((s, i) => {
    const lead = b(i === 0 ? SCHEDULE.firstLead : SCHEDULE.lead);
    const tail = b(i === n - 1 ? SCHEDULE.lastTail : s.type === 'hook' ? SCHEDULE.hookTail : s.type === 'check' ? SCHEDULE.checkTail : SCHEDULE.tail);
    const durationInFrames = lead + s.voDurationInFrames + tail;
    const out = {...s, leadFrames: lead, tailFrames: tail, durationInFrames, startFrame: cursor};
    cursor += durationInFrames;
    return out;
  });
  return {...t, scenes, totalDurationInFrames: cursor};
}

export type TxKind = 'cut' | 'pan' | 'slide' | 'portal' | 'flood' | 'zoomout';
export type TxPlan = {kind: TxKind; axis: 'x' | 'y'; tone?: 'red' | 'orange'};

/** Transitions whose incoming/outgoing scenes overlap in time (both on screen). */
export const overlaps = (p?: TxPlan) => p?.kind === 'pan' || p?.kind === 'portal' || p?.kind === 'slide';

/**
 * How each scene is entered — kind carries meaning:
 *   pan     the camera travels across the desk ("this continues")
 *   slide   a fresh sheet is laid over the last one ("new page, same story")
 *   portal  the camera flies through the counter of the chapter's "0" ("we're going inside")
 *   flood   spot ink floods the frame with the chapter name ("stop — register change")
 *   zoomout the camera pulls back from the last scene to reveal the whole lesson (recap)
 *   cut     a hard cut ("wake up")
 */
export function planTransitions(types: Scene['type'][]): TxPlan[] {
  return types.map((type, i) => {
    const prev = types[i - 1];
    if (i === 0 || type === 'hook') return {kind: 'cut', axis: 'x'};
    if (type === 'recap') return {kind: 'zoomout', axis: 'x'};
    if (type === 'mistake') return {kind: 'flood', axis: 'x', tone: 'red'};
    if (type === 'check') return {kind: 'flood', axis: 'x', tone: 'orange'};
    if (type === 'answer') return {kind: 'slide', axis: 'x'};
    if (type === 'figure') return prev === 'figure' ? {kind: 'slide', axis: 'x'} : {kind: 'portal', axis: 'x'};
    if (type === 'pseudocode' || type === 'code') return {kind: 'portal', axis: 'x'};
    if (type === 'example') return prev === 'pseudocode' || prev === 'code' ? {kind: 'slide', axis: 'x'} : {kind: 'portal', axis: 'x'};
    if (type === 'steps') return prev === 'steps' ? {kind: 'pan', axis: 'y'} : {kind: 'slide', axis: 'x'};
    return {kind: 'pan', axis: 'x'};
  });
}
