/**
 * House fonts, loaded only from the repo (public/fonts, manifest src/fonts.gen.json — written by
 * scripts/vendor-fonts.mts). No network, no system fallback: a lesson renders identically on
 * a laptop and on a render server. Every face is loaded up front and the render waits for them.
 * scripts/lib/coverage.mts lets preflight prove every on-screen character has a house glyph.
 */
import {cancelRender, continueRender, delayRender, staticFile} from 'remotion';
import FACES from './fonts.gen.json';

type Face = {family: string; weight: number; unicodeRange: string; file: string};
const faces = FACES as Face[];

if (typeof document !== 'undefined' && typeof FontFace !== 'undefined') {
  const handle = delayRender('house fonts');
  Promise.all(
    faces.map((f) => {
      const face = new FontFace(f.family, `url(${staticFile(f.file)}) format('woff2')`, {weight: String(f.weight), style: 'normal', unicodeRange: f.unicodeRange, display: 'block'});
      (document.fonts as unknown as {add: (f: FontFace) => void}).add(face);
      return face.load();
    }),
  )
    .then(() => continueRender(handle))
    // a missing font file must fail the render loudly, never fall back silently
    .catch((e) => cancelRender(new Error(`house fonts failed to load: ${e}`)));
}

const q = (f: string) => `'${f}'`;
/** Fallbacks after the script faces: broad Latin/Greek/Cyrillic, symbols, math. */
const TAIL = [q('Noto Sans'), q('Noto Sans Symbols 2'), q('Noto Sans Math')].join(', ');
export const STACKS = {
  display: `${q('Sora')}, ${q('Anek Devanagari')}, ${q('Anek Kannada')}, ${TAIL}`,
  body: `${q('Inter')}, ${q('Noto Sans Devanagari')}, ${q('Noto Sans Kannada')}, ${TAIL}`,
  mono: `${q('IBM Plex Mono')}, ${q('Noto Sans Devanagari')}, ${q('Noto Sans Kannada')}, ${TAIL}`,
};
